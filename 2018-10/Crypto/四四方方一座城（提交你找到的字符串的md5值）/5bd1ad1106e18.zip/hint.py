from flag import FLAG,key1,key2,Offset
from enc import encrypt

ciphertext = encrypt(FLAG)
enc_key1 = enc_key2 = ""

for i in key1:
	enc_key1 += chr((ord(i) ^ 0xff & 0xaf) + Offset)

for i in key2:
	enc_key2 += chr((ord(i) ^ 0xff & 0xaf) + Offset)

print enc_key1
print enc_key2

#ciphertext:XBBSPASGXRAEUIOHPZ
#enc_key1:VXYjj
#enc_key2:NQLOUVXab